<?php
session_start();

$servername = 'localhost';
$username = 'root';
$password = '';


$firstname=$_GET['firstname'];
$lastname=$_GET['lastname'];
$email=$_GET['email'];
$user_password=$_GET['password'];

if(strlen($firstname) == 0 || strlen($lastname) == 0 || strlen($email) == 0 || strlen($user_password) == 0){
	echo 'Mandatory fields must be filled';
	echo '<meta http-equiv="refresh" content="2; URL=register.html">';
	}
	
//On essaie de se connecter
try{
	$conn = new PDO("mysql:host=$servername;dbname=project_db", $username, $password);
	//On définit le mode d'erreur de PDO sur Exception
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $conn->query("SELECT COUNT(*) FROM user where email='".$_GET['email']."'");
	$res = $stmt->fetch();
	if($res[0] == 1){
	echo 'Email adress already used';
	echo '<meta http-equiv="refresh" content="2; URL=register.html">';
	exit;
	}
	
	$sql = 'INSERT INTO user (firstname,lastname,email,password) VALUES(?,?,?,?);';
	$conn->prepare($sql)->execute([$firstname, $lastname, $email, $user_password]);
	echo '<meta http-equiv="refresh" content="2; URL=index.html">';
	}

/*On capture les exceptions si une exception est lancée et on affiche
 *les informations relatives à celle-ci*/
catch(PDOException $e){
  echo "Erreur : " . $e->getMessage();
}